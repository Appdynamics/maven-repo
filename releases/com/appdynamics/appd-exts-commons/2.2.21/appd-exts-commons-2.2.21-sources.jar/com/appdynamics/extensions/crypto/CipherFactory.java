/*
 * Copyright (c) 2019 AppDynamics,Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.appdynamics.extensions.crypto;


import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;


class CipherFactory {

    private static final CipherFactory _instance = new CipherFactory();

    // Legacy static IV kept only for decrypting values encrypted before this fix.
    static final byte[] LEGACY_IV = {(byte) 0xC2, (byte) 0xB9, (byte) 0xC8, (byte) 0x52,
            (byte) 0x96, (byte) 0x14, (byte) 0xE4, (byte) 0x53, (byte) 0x54, (byte) 0xC9, (byte) 0x76, (byte) 0x67,
            (byte) 0x78, (byte) 0x94, (byte) 0x12, (byte) 0x32};

    // Version byte prepended to new-format ciphertexts so Decryptor can tell them apart from legacy ones.
    static final byte FORMAT_VERSION = 0x01;

    static CipherFactory getInstance() {
        return _instance;
    }

    Cipher createCipher(String encryptionKey, byte[] iv, int mode) throws CipherInitException {
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            byte[] hash = getHash(encryptionKey);
            SecretKey secret = new SecretKeySpec(hash, "AES");
            cipher.init(mode, secret, new IvParameterSpec(iv));
            return cipher;
        } catch (NoSuchAlgorithmException e) {
            throw new CipherInitException(e);
        } catch (InvalidKeyException e) {
            throw new CipherInitException(e);
        } catch (NoSuchPaddingException e) {
            throw new CipherInitException(e);
        } catch (InvalidAlgorithmParameterException e) {
            throw new CipherInitException(e);
        }
    }

    private byte[] getHash(String encryptionKey) throws NoSuchAlgorithmException {
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        byte[] passBytes = encryptionKey.getBytes();
        byte[] passHash = sha256.digest(passBytes);
        /* SHA-256 gives a 256-bit hash or 32 byte hash. AES by default supports 128-bit.
           To support larger keysize JCE unlimited policy files need to be placed in JRE-HOME/lib/security dir.
           http://www.informit.com/articles/article.aspx?p=170967&seqNum=11.
           To avoid that, extracting the last 16 bytes (128-bit) from a 32 byte word hash.
         */
        return get16ByteHash(passHash);
    }

    private byte[] get16ByteHash(byte[] passHash) {
        byte[] hash_16_byte = new byte[16];
        System.arraycopy(passHash, 16, hash_16_byte, 0, 16);
        return hash_16_byte;
    }

    byte[] generateIv() {
        byte[] iv = new byte[16];
        new SecureRandom().nextBytes(iv);
        return iv;
    }
}
